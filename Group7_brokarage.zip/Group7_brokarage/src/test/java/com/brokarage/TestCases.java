package com.brokarage;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestCases {
	
	public WebDriver driver;
	public ExtentReports extent;
	public ExtentTest extentTest;

	
	
	@BeforeTest
	public void setExtent(){
		extent = new ExtentReports(System.getProperty("user.dir")+"/test-output/ExtentReport.html", true);
		extent.addSystemInfo("Host Name", "Group 7");
		extent.addSystemInfo("User Name", "Group 7");
		extent.addSystemInfo("Environment", "PROD");
		
	}
	
	@AfterTest
	public void endReport(){
		extent.flush();
		extent.close();
	}
	
	public static String getScreenshot(WebDriver driver, String screenshotName) throws IOException{
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/" + screenshotName + dateName+ ".png";
		File finalDestination = new File(destination);
		FileUtils.copyFile(source, finalDestination);
		return destination;
	}
	
	
	
	
	@BeforeMethod
	public void setup(){
		String path = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", path+"/Drivers/chromedriver.exe");	
		driver = new ChromeDriver(); 
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("https://www.interactivebrokers.com/en/home.php");
		
	}
	
	
	@Test (priority=13)
	public void logo_validation(){
		extentTest = extent.startTest("Logo Validation ");
		boolean b = driver.findElement(By.xpath("//a[@title='Interactive Brokers Home']")).isDisplayed();
		Assert.assertTrue(b);
	}
	
	
	@Test (priority=12)
	public void signUp(){
		extentTest = extent.startTest("Sign up form");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("window.scrollBy(0,250)", "");
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation2508");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Password1");
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='password2']")));
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys(Keys.TAB);
		driver.findElement(By.xpath("//input[@id='password2']")).sendKeys("Password1");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@id='accountCreationButton']")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		String actualText = driver.findElement(By.xpath("//h3[@class='text-success']")).getText();
		Assert.assertEquals(actualText,"Your Free Trial Account is All Set!");
		
	}
	
	
	@Test (priority=11)
	public void login() {
		extentTest = extent.startTest("Login verification");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='user_name']")).sendKeys("group742022");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Password1");
		driver.findElement(By.xpath("//div[@id='twofactauth']//button[@id='submitForm']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String actual = driver.findElement(By.xpath("//*[@id=\"applicationForm\"]/section/div/div[1]/div/h2/strong")).getText();
		Assert.assertEquals(actual,"Check your email and confirm your email address");
	}
	
	
	@Test (priority=1)
	public void testcase1() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 7 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("7777777");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#e62333");
	//	#009947

	}
	
	@Test (priority=2)
	public void testcase2() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 8 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("88888888");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947

	}
	
	@Test (priority=3)
	public void testcase3() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 9 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("999999999");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947

	}
	
	@Test (priority=4)
	public void testcase4() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 39 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("123456789123456789123456789123456789123");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947

	}
	
	@Test (priority=5)
	public void testcase5() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 41 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("12345678912345678912345678912345678912345");
		
//		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
//		driver.findElement(By.xpath("//input[@id='password']")).click();
//		Thread.sleep(2000);
//		String css = text.getCssValue("color");
//		String color = Color.fromString(css).asHex();
//		System.out.println("Hex code for color:" + color);
//		
//		Assert.assertEquals(color,"#009947");
	//	#009947

	}
	
	@Test (priority=6)
	public void testcase6() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password is Entered  with 20 characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("12345678912345678912");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck1\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947

	}
	
	@Test (priority=7)
	public void testcase7() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password entered with 0 letters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("12345678");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck2\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#e62333");
	//	#009947

	}
	
	@Test (priority=8)
	public void testcase8() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password entered with 1 letters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("12345678a");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck2\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947 #e62333

	}
	
	@Test (priority=9)
	public void testcase9() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password entered with 2 letters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("12345678ab");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck2\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#009947");
	//	#009947 #e62333

	}
	
	@Test (priority=10)
	public void testcase10() throws InterruptedException{
		extentTest = extent.startTest("Check if error message is displayed when password entered with only special characters");
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals(title,"Home | Interactive Brokers LLC");
		
		driver.findElement(By.xpath("//a[@id='nav-open-account']")).click();
			
		
		driver.findElement(By.xpath("//a[@class='dropdown-item'][normalize-space()='Finish an Application']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//a[@class='inline text-dark-blue']")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		
		Random randomGenerator = new Random();  
		int randomInt = randomGenerator.nextInt(1000);  
		String spam = "+spam";
		
		
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys("user"+randomInt + spam +"@gmail.com");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='emailAddress']")).sendKeys(Keys.TAB);

		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("Automation1708");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("!@#$%^&*");
		
		WebElement text = driver.findElement(By.xpath("//*[@id=\"pwCheck2\"]"));
		driver.findElement(By.xpath("//input[@id='password']")).click();
		Thread.sleep(2000);
		String css = text.getCssValue("color");
		String color = Color.fromString(css).asHex();
		System.out.println("Hex code for color:" + color);
		
		Assert.assertEquals(color,"#e62333");
	//	#009947 #e62333

	}
	
	
	@AfterMethod
	public void tearDown(ITestResult result) throws IOException{
		
		if(result.getStatus()==ITestResult.FAILURE){
			extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS "+result.getName()); //to add name in extent report
			extentTest.log(LogStatus.FAIL, "TEST CASE FAILED IS "+result.getThrowable()); //to add error/exception in extent report
			
			String screenshotPath = TestCases.getScreenshot(driver, result.getName());
			extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(screenshotPath)); //to add screenshot in extent report
			//extentTest.log(LogStatus.FAIL, extentTest.addScreencast(screenshotPath)); //to add screencast/video in extent report
		}
		else if(result.getStatus()==ITestResult.SKIP){
			extentTest.log(LogStatus.SKIP, "Test Case SKIPPED IS " + result.getName());
		}
		else if(result.getStatus()==ITestResult.SUCCESS){
			extentTest.log(LogStatus.PASS, "Test Case PASSED IS " + result.getName());

		}
		
		
		extent.endTest(extentTest); //ending test and ends the current test and prepare to create html report
		driver.quit();
	}
	

}
